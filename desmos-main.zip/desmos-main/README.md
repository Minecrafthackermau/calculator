# Idle Breakout
Build the ultimate brick-busting machine to destroy billions of bricks. Idle breakout combines classic brick breaking with an insanely addicting idle loop.

![thumbnail](https://user-images.githubusercontent.com/58097612/140560557-fde4d050-0a89-44aa-b8e1-2d7fc837f8fc.png)

## Play

Want to join the action?

[Click here to start playing!](https://ctrl-shift-u-221e.github.io/desmos/)

## Photots

Here are some screenshots if you are not conviced this game is great!

### This is how you start:
![Screenshot 2021-11-05 2 28 14 PM](https://user-images.githubusercontent.com/58097612/140563490-1041ed31-f565-4b2e-9cdb-d55973f969b0.png)

### This is what you get to:
![Screenshot 2021-11-05 2 28 34 PM](https://user-images.githubusercontent.com/58097612/140563564-b56f2a84-81a3-487d-87b7-e72f3fc544f8.png)

[Hurry up and play it!](https://ctrl-shift-u-221e.github.io/desmos/)
